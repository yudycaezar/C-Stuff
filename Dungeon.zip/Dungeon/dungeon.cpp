#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <time.h>

struct Unit{
	int row;
	int column;
}player, target;

char maps[12][23];
int score = 0;
int input;
int movementCount = 0;

void printMap(){
	for(int i=0; i<12 ; i++){
		for(int j=0 ; j<23 ; j++){
			if(maps[i][j] == '.'){
				printf(" ");
			}
			else{
				printf("%c", maps[i][j]);
			}
			
		}
		printf("\n");
	}
	printf("Score         : %d\n", score);
	printf("Movement count: %d", movementCount);
}

void generatePlayer(){
	int row, column;
	do{
		row = rand()%12;
		column = rand()%23;
	}while( maps[row][column] != '.' );
	player.row = row;
	player.column = column;
	maps[player.row][player.column] = (char)184;
}

void generateTarget(){
	int row, column;
	do{
		row = rand()%12;
		column = rand()%23;
	}while( maps[row][column] == '#' || maps[row][column] == (char)184  );
	target.row = row;
	target.column = column;
	maps[target.row][target.column] = '$';
}

int main(){
	
	srand(time(0));
	
	for(int i=0; i<12 ; i++){
		for(int j=0 ; j<23 ; j++){
			scanf("%c", &maps[i][j]);
		}
		scanf("\n");
	}
	
	generatePlayer();
	generateTarget();
		
	do{
		system("cls");
		printMap();
		input = getch();
		
		switch(input){
			case 'W':
			case 'w':
				if( maps[player.row-1][player.column] != '#' ){
					maps[player.row][player.column] = '.';
					player.row--;
					maps[player.row][player.column] = (char)184;
				}
				break;
				
			case 'S':
			case 's':
				if( maps[player.row+1][player.column] != '#' ){
					maps[player.row][player.column] = '.';
					player.row++;
					maps[player.row][player.column] = (char)184;
				}
				break;
				
			case 'A':
			case 'a':
				if( maps[player.row][player.column-1] != '#' ){
					maps[player.row][player.column] = '.';
					player.column--;
					maps[player.row][player.column] = (char)184;				
				}
				break;
				
			case 'D':
			case 'd':
				if( maps[player.row][player.column+1] != '#' ){
					maps[player.row][player.column] = '.';
					player.column++;
					maps[player.row][player.column] = (char)184;
				}
				break;
		}
		
		if( player.row == target.row && player.column == target.column ){
			score++;
			generateTarget();
		}
		movementCount++;
	}while(1);
	
	
	return 0;
}
