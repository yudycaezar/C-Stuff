#include <stdio.h>
#include <string.h>

#define appname "Blood Bank Application"
#define datafile "data.dat"

struct Data{
	char donorname[100];
	char bloodtype[3];
	char availability[15];
};

void clrscr(){
	for(int i=0 ; i<25 ; i++)
		printf("\n");
}

void swap_arrayofchar(char string1[], char string2[]){
	char stringtemp[100];
	strcpy(stringtemp, string1);
	strcpy(string1, string2);
	strcpy(string2, stringtemp);
}

void swap_integer(int *number1, int *number2){
	int numbertemp;
	numbertemp = *number1;
	*number1 = *number2;
	*number2 = numbertemp;
}

int is_alphabet(char* input){
	for(int i=0 ; i<strlen(input) ; i++){
		if( !(input[i]>='A' && input[i]<='Z') && !(input[i]>='a' && input[i]<='z') && input[i]!=' ' )
			return -1;
	}
	return 0;
}

void reset_count(int* categorycount){
	for(int i=0 ; i<4 ; i++)
		categorycount[i] = 0;
}

int read_data(char* filename, struct Data* blooddata, int count){
	FILE *file = fopen(filename,"r");
	if(!file){
		printf("\n%s can not be started.\n", appname);
		printf("\nMake sure \"%s\" is exist.\n", filename);
		return -1;
	}else{
		fseek(file, 0, SEEK_END);
		if(ftell(file) == 0){
			return 0;
		}
		else{
			fseek(file, 0, SEEK_SET);
			while(!feof(file)){
				fscanf(file, "%[^#]#%[^#]#%[^\n]\n", &blooddata[count].donorname, &blooddata[count].bloodtype, blooddata[count].availability);
				fflush(stdin);
				count++;
			}
			//printf("\nData successfully retrieved : %d data\n", count);
			//printf("Application is now running\n");
			//printf("\nPress enter to continue...");
			//getchar();
			fclose(file);
			return count;
		}
	}
}

void write_file(char* filename, struct Data* blooddata, int count){
	FILE *file = fopen(filename,"w");
	for(int i=0 ; i<count ; i++){
		//printf("%s#%s#%s\n", blooddata[i].donorname, blooddata[i].bloodtype, blooddata[i].availability);
		fprintf(file, "%s#%s#%s\n", blooddata[i].donorname, blooddata[i].bloodtype, blooddata[i].availability);
	}
	printf("\nData successfully saved\n\n", count);
	fclose(file);
}

void print_application_title(){
	printf(" ____  _                 _   ____              _    \n");
	printf("|  _ \\| |               | | |  _ \\            | |   \n");
	printf("| |_) | | ___   ___   __| | | |_) | __ _ _ __ | | __\n");
	printf("|  _ <| |/ _ \\ / _ \\ / _` | |  _ < / _` | '_ \\| |/ /\n");
	printf("| |_) | | (_) | (_) | (_| | | |_) | (_| | | | |   < \n");
	printf("|____/|_|\\___/ \\___/ \\__,_| |____/ \\__,_|_| |_|_|\\_\\\n");
}

void print_application_header(){
	printf("%c", 201);
	for(int i=0 ; i<strlen(appname)+2 ; i++){
		printf("%c", 205);
	}
	printf("%c", 187);
	printf("\n%c %s %c\n", 186, appname, 186);
	printf("%c", 200);
	for(int i=0 ; i<strlen(appname)+2 ; i++){
		printf("%c", 205);
	}
	printf("%c", 188);
	printf("\n\n");
}

void print_application_menu(){
	printf("1. View Data (Sorted by Donor Name)\n");
	printf("2. Insert New Data\n");
	printf("3. Request Blood Transfusion\n");
	printf("4. Save Data and Exit Application\n\n");
}

void print_application_footer(){
	printf(" _____ _              _                   \n");
	printf("|_   _| |_  __ _ _ _ | |__  _  _ ___ _  _ \n");
	printf("  | | | ' \\/ _` | ' \\| / / | || / _ \\ || |\n");
	printf("  |_| |_||_\\__,_|_||_|_\\_\\  \\_, \\___/\\_,_|\n");
	printf("                            |__/          \n");
}

void view_data(struct Data* blooddata, int count, int categorycount[]){
	//memset(categorycount, 0, count*sizeof(int));
	reset_count(categorycount);
	printf("%c", 201);
	for(int i=1 ; i<=55 ; i++){
		if( i==5 )
			printf("%c", 203);
		else if( i==28 )
			printf("%c", 203);
		else if( i==41 )
			printf("%c", 203);
		else
			printf("%c", 205);
	}
	printf("%c\n", 187);
	printf("%c %-2s %c %-20s %c %-10s %c %-12s %c\n", 186, "No", 186, "Donor Name", 186, "Blood Type", 186, "Availability", 186);
	printf("%c", 204);
	for(int i=1 ; i<=55 ; i++){
		if( i==5 )
			printf("%c", 206);
		else if( i==28 )
			printf("%c", 206);
		else if( i==41 )
			printf("%c", 206);
		else
			printf("%c", 205);
	}
	printf("%c\n", 185);
	for(int i=0 ; i<count ; i++){
		printf("%c %-2d %c %-20s %c %-10s %c %-12s %c\n", 186, i+1, 186, blooddata[i].donorname, 186, blooddata[i].bloodtype, 186, blooddata[i].availability, 186);		
		if( strcmp(blooddata[i].bloodtype, "A") == 0 && strcmp(blooddata[i].availability, "Available") == 0 )
			categorycount[0]++;
		else if( strcmp(blooddata[i].bloodtype, "B") == 0 && strcmp(blooddata[i].availability, "Available") == 0 )
			categorycount[1]++;
		else if( strcmp(blooddata[i].bloodtype, "AB") == 0 && strcmp(blooddata[i].availability, "Available") == 0 )
			categorycount[2]++;
		else if( strcmp(blooddata[i].bloodtype, "O") == 0 && strcmp(blooddata[i].availability, "Available") == 0 )
			categorycount[3]++;
	}
	printf("%c", 200);
	for(int i=1 ; i<=55 ; i++){
		if( i==5 )
			printf("%c", 202);
		else if( i==28 )
			printf("%c", 202);
		else if( i==41 )
			printf("%c", 202);
		else
			printf("%c", 205);
	}
	printf("%c\n", 188);
}

void sort_data_by_name_asc(struct Data* blooddata, int count){
	for(int i=0 ; i<count ; i++){
		for(int j=count-1 ; j>0 ; j--){
			if( strcmp(blooddata[j].donorname, blooddata[j-1].donorname) < 0 ){
				swap_arrayofchar(blooddata[j].donorname, blooddata[j-1].donorname);
				swap_arrayofchar(blooddata[j].bloodtype, blooddata[j-1].bloodtype);
				swap_arrayofchar(blooddata[j].availability, blooddata[j-1].availability);
			}
		}
	}
}

struct Data* search_data_by_bloodtype(struct Data* blooddata, char* bloodtype, int count){
	struct Data find;
	for( int i=0 ; i<count ; i++ ){
		if( strcmp(blooddata[i].bloodtype, bloodtype) == 0 && strcmp(blooddata[i].availability, "Available") == 0  )
			return &blooddata[i];
	}
	return NULL;
}

int main(){
	struct Data blooddata[50];
	struct Data newblooddata;
	struct Data* searchblooddata;
	char searchbloodtype[3];
	int datacount = 0;
	int menu = 0;
	int choice = -1;
	int categorycount[4] = {0};
	
	clrscr();
	//print_application_title();	
	//printf("\n\nInitializing %s...\n", appname);
	datacount = read_data(datafile, blooddata, datacount);

	if( datacount == -1 ){
		printf("\nPress enter to exit...");
		getchar();
		return 0;
	}
	
	do{
		sort_data_by_name_asc(blooddata, datacount);
		clrscr();
		print_application_header();

		do{
			print_application_menu();
			printf("Input your choice: ");
			scanf("%d", &menu);
			fflush(stdin);
		}while( menu<1 || menu>4 );

		switch(menu){
			
			case 1:
				clrscr();

				//printf("%d", datacount);
				
				printf("View Data (Sorted by Donor Name)\n\n");	
				view_data(blooddata, datacount, categorycount);

				printf("\nNumber of available blood transfusion:\n");
				printf("- Blood type A : %d\n", categorycount[0]);
				printf("- Blood type B : %d\n", categorycount[1]);
				printf("- Blood type AB: %d\n", categorycount[2]);
				printf("- Blood type O : %d\n", categorycount[3]);
				

				printf("\nPress enter to continue...");
				getchar();
				break;

			case 2:
				clrscr();
				printf("Insert New Data\n\n");

				do{
					printf("Donor Name [4-20 characters (alphabet only)]: ");
					scanf("%[^\n]", &newblooddata.donorname);
					fflush(stdin);
				}while( strlen(newblooddata.donorname)<4 || strlen(newblooddata.donorname)>30 || is_alphabet(newblooddata.donorname) == -1 );

				do{
					printf("Donor Blood Type [ A | B | O | AB ]: ");
					scanf("%s", &newblooddata.bloodtype);
					fflush(stdin);
				}while( strcmp(newblooddata.bloodtype, "A")!=0 && 
						strcmp(newblooddata.bloodtype, "B")!=0 &&
						strcmp(newblooddata.bloodtype, "O")!=0 &&
						strcmp(newblooddata.bloodtype, "AB")!=0 );
				
				strcpy(newblooddata.availability, "Available");

				blooddata[datacount] = newblooddata;
				datacount++;

				printf("Insert data success!\n\n");

				printf("\nPress enter to continue...");
				getchar();
				break;

			case 3:
				clrscr();
				printf("Request Blood Transfusion\n\n");
				view_data(blooddata, datacount, categorycount);				
				printf("\n");

				do{
					printf("Blood Type [ A | B | O | AB ]: ");
					scanf("%s", &searchbloodtype);
					fflush(stdin);
				}while( strcmp(searchbloodtype, "A")!=0 && 
						strcmp(searchbloodtype, "B")!=0 &&
						strcmp(searchbloodtype, "O")!=0 &&
						strcmp(searchbloodtype, "AB")!=0 );

				searchblooddata = search_data_by_bloodtype(blooddata, searchbloodtype, datacount);


				if( searchblooddata == NULL ){
					printf("\nSorry, no blood transfusion available for that type of blood right now\n\n");
				}
				else{
					printf("\n\nBlood transfusion available found\n\n");
					printf("Donor Name   : %s\n", (*searchblooddata).donorname);
					printf("Blood Type   : %s\n", (*searchblooddata).bloodtype);
					printf("Availability : %s\n", (*searchblooddata).availability);
					printf("\nRequesting blood transfusion process\n");

					strcpy((*searchblooddata).availability, "Unavailable");
				}

				printf("\nPress enter to continue...");
				getchar();
				break;
		}

	}while(menu != 4);

	clrscr();
	write_file("data.dat", blooddata, datacount);
	print_application_footer();
	printf("\nPress enter to exit...");
	getchar();
	return 0;
}
