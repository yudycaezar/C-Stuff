#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>

#define EASY 4
#define MEDIUM 16
#define HARD 64

#define CLOSED 0
#define OPENED 1
#define MATCHED 2

struct Tile{
	int index;
	char symbol;
	int status;
};

struct HallOfFame{
	int difficulty;
	char nickname[4];
	int score;
};

int G_gameDifficulty;

void generate_list_of_characters(char* charactersUsed){
	int index = 0;
	for(int i=65 ; i<91 ; i++){
		charactersUsed[index++] = i;
	}
	for(int i=48 ; i<54 ; i++){
		charactersUsed[index++] = i;
	}
}

void initialize_board(const char* charactersUsed, Tile* boards){
	int listOfTakenCharacters[32];
	int charIndex;

	for(int i=0 ; i<32 ; i++){
		listOfTakenCharacters[i] = 2;
	}
	
	for(int i=1 ; i<=G_gameDifficulty ; i++){
		do{
			charIndex = rand()%(G_gameDifficulty/2);
		}while( listOfTakenCharacters[charIndex] == 0 );
		boards[i].index = i;
		boards[i].symbol = charactersUsed[charIndex];
		boards[i].status = CLOSED;
		listOfTakenCharacters[charIndex]--;
	}	
}

void print_board(Tile* boards){
	int divide = sqrt((double)G_gameDifficulty);
	printf(" # | ");
	for(int i=0 ; i<divide ; i++){
		printf("%d | ", i+1);
	}
	printf("\n");
	for(int i=1 ; i<=G_gameDifficulty ; i++){
		if( i%divide == 1 ){
			printf(" %d | ", (i/divide)+1);
		}
		switch(boards[i].status){
			case OPENED:
				printf("%c | ", boards[i].symbol);
				break;
			
			case CLOSED:
				printf("- | ");
				break;
		}		
		if( i%divide == 0 ){
			printf("\n");
		}
		
	}
}

void title(){
	printf("  __  __  U _____ u  __  __    U  ___ u   ____     __   __ \n");
	printf("U|' \\/ '|u\\| ___\"|/U|' \\/ '|u   \\/\"_ \\/U |  _\"\\ u  \\ \\ / / \n");
	printf("\\| |\\/| |/ |  _|\"  \\| |\\/| |/   | | | | \\| |_) |/   \\ V /  \n");
	printf(" | |  | |  | |___   | |  | |.-,_| |_| |  |  _ <    U_|\"|_u \n");
	printf(" |_|  |_|  |_____|  |_|  |_| \\_)-\\___/   |_| \\_\\     |_|   \n");
	printf("<<,-,,-.   <<   >> <<,-,,-.       \\\\     //   \\\\_.-,//|(_  \n");
	printf(" (./  \\.) (__) (__) (./  \\.)     (__)   (__)  (__)\\_) (__) \n");
}

int is_valid_tile(int row, int column, Tile* boards){
	int maximumRowColumnValue = sqrt(G_gameDifficulty);
	int tileIndex = ((row-1)*sqrt(G_gameDifficulty)) + column;
	if( row<0 || column<0 || row>maximumRowColumnValue || column>maximumRowColumnValue ){
		return -1;
	}
	else if( boards[tileIndex].status == OPENED ){
		return -2;
	}
	return 0;
}

int read_hall_of_fame(HallOfFame* lists, int difficulty){
	int index = 0;
	HallOfFame scoreTemp;
	
	FILE *f = fopen("hall-of-fame.txt", "r");
	while(!feof(f)){
		fscanf(f, "%d#%[^#]#%d\n", &scoreTemp.difficulty, &scoreTemp.nickname, &scoreTemp.score);
		if( scoreTemp.difficulty == difficulty ){
			lists[index] = scoreTemp;
			index++;
		}
	}	
	fclose(f);
	return index;
}

void sort(HallOfFame* lists, int index){
	for(int i=0 ; i<index-1 ; i++){
		for(int j=index-1 ; j>i ; j--){
			if( lists[j].score <= lists[j-1].score ){
				if( strcmp(lists[j].nickname, lists[j-1].nickname) < 0 ){
					HallOfFame temp = lists[j];
					lists[j] = lists[j-1];
					lists[j-1] = temp;
				}				
			}
		}
	}
}

int show_hall_of_fame(HallOfFame* lists, int index){
	index = (index>3) ? 3 : index;
	for(int i=0 ; i<index ; i++){
		printf("%d. %3s (%-4d)\n", i+1, lists[i].nickname, lists[i].score);
	}
}

void write_hall_of_fame(HallOfFame* easyList, int easyCount, HallOfFame* mediumList, int mediumCount, HallOfFame* hardList, int hardCount){
	FILE *f = fopen("hall-of-fame.txt", "w");
	for(int i=0 ; i<easyCount ; i++){
		fprintf(f, "%d#%s#%d\n", easyList[i].difficulty, easyList[i].nickname, easyList[i].score);
	}
	for(int i=0 ; i<mediumCount ; i++){
		fprintf(f, "%d#%s#%d\n", mediumList[i].difficulty, mediumList[i].nickname, mediumList[i].score);
	}
	for(int i=0 ; i<hardCount  ; i++){
		fprintf(f, "%d#%s#%d\n", hardList[i].difficulty, hardList[i].nickname, hardList[i].score);
	}	
	fclose(f);
}

int main(){
	srand(time(NULL));
		
	char charactersUsed[32];
	
	Tile boards[65] = {0};
	HallOfFame listsEasy[10000];
	HallOfFame listsMedium[10000];
	HallOfFame listsHard[10000];
	
	HallOfFame newScore;
	char newNickname[4];
	
	char confirmation = 'N';
	int numberOfOpenedTile = 0;
	int tileTurn = 0;
	int tileIndex = 0;
	int row = 0;
	int column = 0;
	int isValidTileInput = -1;
	int tileIndexCurrentlyOpened[] = {0,0};
	
	int hallOfFameEasyCount = read_hall_of_fame(listsEasy, EASY);
	int hallOfFameMediumCount = read_hall_of_fame(listsMedium, MEDIUM);
	int hallOfFameHardCount = read_hall_of_fame(listsHard, HARD);
	
	generate_list_of_characters(charactersUsed);
	
	do{
		do{
			system("cls");
			title();
			printf("\n\n");
			printf("Choose your difficulty level [0 to exit]:\n");
			printf("1) LoL\n");
			printf("2) Close Enough\n");
			printf("3) GGWP\n");
			do{
				printf(">> ");
				scanf("%d", &G_gameDifficulty);
				fflush(stdin);
			}while( G_gameDifficulty<0 || G_gameDifficulty>3 );
			
			do{
				printf("Seriously??? [Y/N]: ");
				scanf("%c", &confirmation);
				fflush(stdin);
			}while( confirmation != 'Y' && confirmation != 'N' );
		}while( confirmation != 'Y' );
		
		if( G_gameDifficulty == 0 ){
			write_hall_of_fame(listsEasy, hallOfFameEasyCount, listsMedium, hallOfFameMediumCount, listsHard, hallOfFameHardCount);
			printf("\nSee yaaa!!!");
			getchar();
			break;
		}
		
		system("cls");
		
		printf("Hall of Fame - Easy\n");
		printf("==========================\n");		
		
		show_hall_of_fame(listsEasy, hallOfFameEasyCount);
		printf("\n");
		
		printf("Hall of Fame - Medium\n");
		printf("==========================\n");		
		show_hall_of_fame(listsMedium, hallOfFameMediumCount);
		printf("\n");
		
		printf("Hall of Fame - Hard\n");
		printf("==========================\n");
		show_hall_of_fame(listsHard, hallOfFameHardCount);
		printf("\n");
		
		printf("Let's 'PLAY' !!! (Press ENTER to continue...)");
		getchar();
		
		G_gameDifficulty = pow(2, 2*G_gameDifficulty);
		initialize_board(charactersUsed, boards);
		numberOfOpenedTile = 0;
		
		do{
			system("cls");
			printf("Turn: %d\n\n", tileTurn);
			print_board(boards);
			
			printf("\n\n");
			do{
				printf("Input tile-%d to open [row column]: ", tileTurn%2+1);
				scanf("%d %d", &row, &column);
				fflush(stdin);
				
				isValidTileInput = is_valid_tile(row, column, boards);
				
				switch(isValidTileInput){
					case -1:
						printf("Bad Input: Invalid row or column value!\n\n");
						break;
					
					case -2:
						printf("Bad Input: Tile has been opened!\n\n");
						break;
				}
				
			}while( isValidTileInput != 0 );
			
			tileIndex = ((row-1)*sqrt(G_gameDifficulty)) + column;
			
			boards[tileIndex].status = OPENED;
			tileIndexCurrentlyOpened[tileTurn%2] = tileIndex;			
			tileTurn++;
			
			system("cls");
			printf("Turn: %d\n\n", tileTurn);
			print_board(boards);
						
			if( tileTurn % 2 == 0 ){
				
				if( boards[tileIndexCurrentlyOpened[0]].symbol == boards[tileIndexCurrentlyOpened[1]].symbol ){
					numberOfOpenedTile+=2;
					printf("\n\nYeah!\n");
				}
				else{
					boards[tileIndexCurrentlyOpened[0]].status = CLOSED;
					boards[tileIndexCurrentlyOpened[1]].status = CLOSED;
					printf("\n\nNope!\n");
				}
			
				printf("Press ENTER to continue...");
				getchar();	
			}
			
		}while( numberOfOpenedTile != G_gameDifficulty );
		
		printf("\n\n");
		
		do{
			printf("Input your nickname [3 characters]: ");
			scanf("%s", &newNickname);
			fflush(stdin);
		}while( strlen(newNickname) != 3 );
		
		if( G_gameDifficulty == EASY ){
			listsEasy[hallOfFameEasyCount].difficulty = G_gameDifficulty;
			strcpy(listsEasy[hallOfFameEasyCount].nickname, newNickname);
			listsEasy[hallOfFameEasyCount].score = tileTurn;
			hallOfFameEasyCount++;
			sort(listsEasy, hallOfFameEasyCount);	
		}
		else if( G_gameDifficulty == MEDIUM ){
			listsMedium[hallOfFameMediumCount].difficulty = G_gameDifficulty;
			strcpy(listsMedium[hallOfFameMediumCount].nickname, newNickname);
			listsMedium[hallOfFameMediumCount].score = tileTurn;
			hallOfFameMediumCount++;
			sort(listsMedium, hallOfFameMediumCount);
		}
		else if( G_gameDifficulty == HARD ){
			listsHard[hallOfFameHardCount].difficulty = G_gameDifficulty;
			strcpy(listsHard[hallOfFameHardCount].nickname, newNickname);
			listsHard[hallOfFameHardCount].score = tileTurn;
			hallOfFameHardCount++;
			sort(listsHard, hallOfFameHardCount);
		}
		
		printf("\n\nPress ENTER to continue...");
		getchar();
		
	}while( 1 );
	
	return 0;
}
