#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <windows.h>

#define TIER_COUNT 15
#define IS_AVAILABLE 1
#define IS_NOT_AVAILABLE 0
#define IS_SURRENDER 1
#define IS_NOT_SURRENDER 0

#define FIFTY_FIFTY 'E'
#define SURRENDER 'F'

struct Question{
	int id;
	char questionText[1000];
	char options[5][100];
	int answer;
};

struct Score{
	int prize;
	char nickname[100];
};

const int prizeTier[16] = {0,
						500, 1000, 2000, 3000, 5000,
						7500, 10000, 15000, 25000, 50000,
						75000, 150000, 250000, 500000, 1000000
						};

void swap_scores(Score *score1, Score *score2){
	Score temp = *score1;
	*score1 = *score2;
	*score2 = temp;
}

void display_scores(Score *scoreList, int scoresCount){
	for(int i=0 ; i<scoresCount-1 ; i++){
		for(int j=scoresCount-1 ; j>i ; j--){
			if( scoreList[j].prize == scoreList[j-1].prize ){
				if( strcmp(scoreList[j].nickname, scoreList[j-1].nickname) < 0 ){
					swap_scores(&scoreList[j], &scoreList[j-1]);
				}
			}
			else if( scoreList[j].prize > scoreList[j-1].prize ){
				swap_scores(&scoreList[j], &scoreList[j-1]);
			}
		}
	}
	printf("Hall of Fame\n");
	printf("=================================\n");
	for(int i=0 ; i<scoresCount ; i++){
		printf("%003d. %-20s %7d\n", i+1, scoreList[i].nickname, scoreList[i].prize);
	}
}

int read_scores_file(Score *scoreList){
	int index = 0;
	FILE *f = fopen("scores.txt", "r");
	if( !f )
		return 0;
	while(!feof(f)){
		fscanf(f, "%[^#]#%d\n", scoreList[index].nickname, &scoreList[index].prize);
		index++;
	}
	fclose(f);
	return index;
}

void write_scores_file(Score *scoreList, int scoresCount){
	FILE *f = fopen("scores.txt", "w");
	for(int i=0 ; i<scoresCount ; i++){
		fprintf(f, "%s#%d\n", scoreList[i].nickname, scoreList[i].prize);
	}
	fclose(f);
}

int read_questions_file(Question *questionList){
	int index = 1;
	FILE *f = fopen("questions.txt", "r");
	
	if( !f )
		return -1;
	
	while(!feof(f)){
		questionList[index].id = index;
		fscanf(f, "%[^#]#%[^#]#%[^#]#%[^#]#%[^@]@%d\n",
			questionList[index].questionText,
			questionList[index].options[1],
			questionList[index].options[2],
			questionList[index].options[3],
			questionList[index].options[4],
			&questionList[index].answer
			);
		index++;
	}
	fclose(f);
	return index;
}

void swap_questions(Question *question1, Question *question2){
	Question temp = *question1;
	*question1 = *question2;
	*question2 = temp;
}

void shuffle_questions(Question *questionList, int questionsCount){
	int randomValue;
	for(int i=questionsCount-1; i>1 ; i--){
		randomValue = rand()%(i+1)+1;
		swap_questions(&questionList[i], &questionList[randomValue]);
	}
}

void print_all_questions(Question *questionList, int questionsCount){
	for(int i=0 ; i<questionsCount ; i++){
		printf("%s\n", questionList[i].questionText);
	}
}

void display_title(){	
	printf(" __  __  _  _  _  _                       _            \n");
	printf("|  \\/  |(_)| || |(_)                     (_)           \n");
	printf("| \\  / | _ | || | _   ___   _ __    __ _  _  _ __  ___ \n");
	printf("| |\\/| || || || || | / _ \\ | '_ \\  / _` || || '__|/ _ \\\n");
	printf("| |  | || || || || || (_) || | | || (_| || || |  |  __/\n");
	printf("|_|  |_||_||_||_||_| \\___/ |_| |_| \\__,_||_||_|   \\___|\n");                               
}

void display_progress(int currentLevel){
	for(int i=TIER_COUNT ; i>0 ; i--){
		if( i==currentLevel ){
			if( i%5==0 ){
				printf("[x] $%7d\t<-Safe Zone %d\n", prizeTier[i], i/5);
			}
			else{
				printf("[x] $%7d\n", prizeTier[i]);
			}			
		}
		else{
			if( i%5==0 ){
				printf("[ ] $%7d\t<- Safe Zone %d\n", prizeTier[i], i/5);
			}
			else{
				printf("[ ] $%7d\n", prizeTier[i]);
			}
			
		}		
	}	
}

void print_question(Question question){

	printf("%c", 201);
	for(int i=1 ; i<=70 ; i++){
		printf("%c", 205);
	}
	printf("%c\n", 187);
	
	printf("%c %-68s %c\n", 186, question.questionText, 186);
	
	printf("%c", 204);
	for(int i=1 ; i<=70 ; i++){
		if( i == 35 )
			printf("%c", 203);
		else
			printf("%c", 205);
	}
	printf("%c\n", 185);
	
	printf("%c A: %-29s %c B: %-29s  %c\n", 186, question.options[1], 186, question.options[2], 186);
	
	printf("%c", 204);
	for(int i=1 ; i<=70 ; i++){
		if( i == 35 )
			printf("%c", 206);
		else
			printf("%c", 205);
	}
	printf("%c\n", 185);
	
	printf("%c C: %-29s %c D: %-29s  %c\n", 186, question.options[3], 186, question.options[4], 186);
	
	printf("%c", 200);
	for(int i=1 ; i<=70 ; i++){
		if( i == 35 )
			printf("%c", 202);
		else
			printf("%c", 205);
	}
	printf("%c\n", 188);
	
}

void do_fifty_fifty(Question *question){
	int indexOfOptions[5] = {0};
	int removedAnswer;
	
	do{
		removedAnswer = rand()%4+1;
	}while( indexOfOptions[removedAnswer]==1 || removedAnswer==question->answer );
	indexOfOptions[removedAnswer]=1;
	
	do{
		removedAnswer = rand()%4+1;
	}while( indexOfOptions[removedAnswer]==1 || removedAnswer==question->answer );
	indexOfOptions[removedAnswer]=1;
	
	for(int i=1 ; i<=4 ; i++){
		if( indexOfOptions[i] == 1 ){
			strcpy(question->options[i], "-");
		}
	}
}

int calculate_prize(int currentLevel, int isSurrender){
	if(isSurrender == IS_SURRENDER){
		return prizeTier[currentLevel-1]/2;
	}
	
	int lastSafeLevel = currentLevel/5;
	return prizeTier[lastSafeLevel*5];
}

int main(){
	srand(time(NULL));
	
	Question database[20];
	Question questionList[20];
	Score scoreList[1000];
	Score newScore;
		
	int questionsCount;
	int scoresCount;
	int inputMenu;
	int currentLevel;
	int fiftyFifty;
	int answerInInt;
	int prize;
	
	char answer;
	char confirmation;
	char nickname[100];
	
	questionsCount = read_questions_file(database);
	scoresCount = read_scores_file(scoreList);
		
	if( questionsCount == -1 ){
		printf("Fail to load \"questions.txt\" file.\nAborting the application...");
		getchar();
		return 1;
	}
	
	if( scoresCount == 0 ){
		printf("Fail to load \"scores.txt\" file.");
		printf("\nPress ENTER to continue...");
		getchar();
	}
	
	do{		
		system("cls");
		display_title();
		
		printf("\n\n");
		printf("MENU\n");
		printf("1. Let's Play!!\n");
		printf("2. Hall of Fame\n");
		printf("3. Exit and Save Hall of Fame\n");
		
		do{
			printf(">> ");
			scanf("%d", &inputMenu);
			fflush(stdin);
		}while(inputMenu<1 || inputMenu>3);
		
		switch(inputMenu){
			
			case 1:
				memcpy(questionList, database, sizeof(database));				
				shuffle_questions(questionList, questionsCount);
			
				currentLevel = 1;
				fiftyFifty = 1;
				prize = 0;
				
				do{
					system("cls");					
					display_progress(currentLevel);
					printf("\nGet ready for $%d question! Press ENTER to continue...", prizeTier[currentLevel]);
					getchar();
					
					system("cls");
					print_question(questionList[currentLevel]);
					do{
						do{
							
							if(fiftyFifty == IS_AVAILABLE){
								printf("Input 'E' to use 50:50\n");
							}
							printf("Input 'F' to surrender\n");
							printf("Your answer: ");
							scanf("%c", &answer);
							fflush(stdin);
							
							if( answer == FIFTY_FIFTY ){
								if(fiftyFifty == IS_AVAILABLE){
									do_fifty_fifty(&questionList[currentLevel]);
									fiftyFifty--;
									system("cls");
									print_question(questionList[currentLevel]);
								}
								else{
									printf("You have used your 50:50!\n\n");
								}
							}
							
							if( answer == SURRENDER ){
								break;
							}
							
						}while( answer<'A' || answer>'D' );
						
						do{
							if( answer == SURRENDER){
								printf("Are you sure to surrender? [Y/N]: ");
							}
							else{
								printf("Lock your answer to %c? [Y/N]: ", answer);
							}							
							scanf("%c", &confirmation);
							fflush(stdin);
						}while( confirmation!='Y' &&  confirmation!='N' );
						
					}while( confirmation=='N' );
					
					if( answer == SURRENDER ){
						system("cls");
						prize = calculate_prize(currentLevel, IS_SURRENDER);
						printf("Thank you for playing.\n");
						printf("You got $%d\n\n", prize);
						
						do{
							printf("Please input your nickname [5-10 characters]: ");
							scanf("%[^\n]", &nickname);
							fflush(stdin);
						}while( strlen(nickname)<5 || strlen(nickname)>10 );
						
						strcpy(scoreList[scoresCount].nickname, nickname);
						scoreList[scoresCount].prize = prize;
						scoresCount++;						
						break;
					}
					
					if( ((int)answer - 64) == questionList[currentLevel].answer ){
						printf("\nYou are right! You won $%d", prizeTier[currentLevel]);
						currentLevel++;
					
						if( currentLevel > TIER_COUNT ){
							getchar();
							prize = calculate_prize(currentLevel, IS_NOT_SURRENDER);
							system("cls");
							printf("Congratulations! You are the next Millionaire!!\n\n");
							
							do{
								printf("Please input your nickname [5-10 characters]: ");
								scanf("%[^\n]", &nickname);
								fflush(stdin);
							}while( strlen(nickname)<5 || strlen(nickname)>10 );
							strcpy(scoreList[scoresCount].nickname, nickname);
							scoreList[scoresCount].prize = prize;
							scoresCount++;	
							break;
						}
															
						printf("\nPress ENTER to continue...");
						getchar();
					}
					else{
						prize = calculate_prize(currentLevel, IS_NOT_SURRENDER);
						system("cls");
						printf("Sorry, you got the answer wrong.\n");
						printf("Thank you for playing.\n");
						printf("You got $%d\n\n", prize);
						
						do{
							printf("Please input your nickname [5-10 characters]: ");
							scanf("%[^\n]", &nickname);
							fflush(stdin);
						}while( strlen(nickname)<5 || strlen(nickname)>10 );
						strcpy(scoreList[scoresCount].nickname, nickname);
						scoreList[scoresCount].prize = prize;
						scoresCount++;
						
						break;
					}
					
				}while( 1 );
				
				printf("\nPress ENTER to continue...");
				getchar();
				break;
				
			case 2:
				system("cls");
				display_scores(scoreList, scoresCount);
				printf("\nPress ENTER to continue...");
				getchar();
				break;
			
		}
		
	}while( inputMenu != 3 );
	
	write_scores_file(scoreList, scoresCount);
	printf("\n\"scores.txt\" file has been updated.\n");
	printf("Thank you for playing!\n");
	printf("\nPress ENTER to exit...");
	getchar();
	return 0;
}
